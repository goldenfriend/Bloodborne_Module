Hooks.on('ready', () => {
    CONFIG.DND5E.weaponProperties['arcane'] = 'Arcane';
    CONFIG.DND5E.weaponProperties['long-reach'] = 'Long-Reach';
    CONFIG.DND5E.weaponProperties['piercing'] = 'Piercing';
    CONFIG.DND5E.weaponProperties['scatter'] = 'Scatter';
    CONFIG.DND5E.weaponProperties['serrated'] = 'Serrated';
    CONFIG.DND5E.weaponProperties['trick'] = 'Trick';
    CONFIG.DND5E.weaponProperties['unwieldly'] = 'Unwieldly';
});
