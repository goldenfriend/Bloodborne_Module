Hooks.on('ready', () => {
CONFIG.DND5E.weaponProperties['arcane'] = 'Arcane';
CONFIG.DND5E.weaponProperties['trick'] = 'Trick';
});
